#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Test B.1: Priority Support with Nice Values
int
main(int argc, char *argv[])
{
  printf("=== Testing B.1: Priority Support (Nice Values) ===\n");
  printf("This test verifies nice value weight calculations\n");
  printf("Expected weights: Nice 0=1024, Nice -20=88761, Nice 19=15\n\n");
  
  printf("Press Ctrl+Y to see process weights in CFS mode\n");
  printf("Look for WEIGHT column in process dump\n\n");
  
  // Create processes with different nice values (simulated)
  // In real implementation, you'd set nice values via system call
  int pid = getpid();
  printf("Process PID %d: Default nice=0, expected weight=1024\n", pid);
  
  // Simulate CPU work to show up in scheduler
  for(int i = 0; i < 100000; i++) {
    if(i % 20000 == 0) {
      printf("B.1 Test: CPU work iteration %d (PID: %d)\n", i, pid);
    }
    // Some computation
    int dummy = i * i % 1000;
    (void)dummy;
  }
  
  printf("B.1 Test completed. Check process dump for weight=1024\n");
  exit(0);
}
