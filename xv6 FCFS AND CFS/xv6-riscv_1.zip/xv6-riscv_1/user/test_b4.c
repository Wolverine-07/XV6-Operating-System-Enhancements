#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Test B.4: Dynamic Time Slice Calculation
int
main(int argc, char *argv[])
{
  printf("=== Testing B.4: Dynamic Time Slice Calculation ===\n");
  printf("This test verifies time slice computation based on weight and target latency\n");
  printf("Expected: Higher weight processes get larger time slices\n\n");
  
  printf("Press Ctrl+Y to see TIME_SLICE column in process dump\n");
  printf("Formula: time_slice = (target_latency * weight) / total_weight\n");
  printf("Default target latency: 20 ticks\n\n");
  
  int pid = getpid();
  printf("Process PID %d: Testing time slice calculation\n", pid);
  printf("With default nice=0, weight=1024, expect time_slice around 20 ticks\n\n");
  
  // Create multiple processes to test time slice distribution
  printf("Creating multiple processes to test time slice distribution...\n");
  
  for(int i = 0; i < 2; i++) {
    int child_pid = fork();
    if(child_pid == 0) {
      // Child process
      printf("Child %d (PID: %d) - Check time slice allocation\n", i + 1, getpid());
      
      // Do some work to trigger scheduling
      for(int j = 0; j < 40000; j++) {
        if(j % 15000 == 0) {
          printf("Child %d: Working... time slice should be visible in dump\n", i + 1);
        }
        int dummy = j * (i + 1) % 1000;
        (void)dummy;
      }
      
      exit(0);
    } else if(child_pid < 0) {
      printf("Fork failed for child %d\n", i + 1);
    }
  }
  
  // Parent also does work
  printf("Parent working... observe time slice distribution\n");
  for(int i = 0; i < 30000; i++) {
    if(i % 10000 == 0) {
      printf("B.4 Test: Parent iteration %d - check time slices\n", i);
    }
    int dummy = i * i % 1000;
    (void)dummy;
  }
  
  // Wait for children
  wait(0);
  wait(0);
  
  printf("B.4 Test completed.\n");
  printf("Verification:\n");
  printf("1. Check that time_slice values appeared in process dump\n");
  printf("2. Time slices should be proportional to process weights\n");
  printf("3. Sum of all time slices should approximate target latency\n");
  
  exit(0);
}
