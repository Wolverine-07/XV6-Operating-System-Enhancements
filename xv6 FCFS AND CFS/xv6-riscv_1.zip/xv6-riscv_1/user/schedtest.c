#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
  printf("Starting scheduler test...\n");
  printf("Use Ctrl+Y to see process information\n");
  
  // Fork multiple CPU-intensive processes
  for(int i = 0; i < 3; i++) {
    if(fork() == 0) {
      // Child process - run CPU test
      char id_str[10];
      id_str[0] = '0' + i;
      id_str[1] = '\0';
      exec("cputest", (char*[]){"cputest", id_str, 0});
      printf("exec failed\n");
      exit(1);
    }
  }
  
  // Parent waits for all children
  for(int i = 0; i < 3; i++) {
    wait(0);
  }
  
  printf("All test processes completed\n");
  exit(0);
}
