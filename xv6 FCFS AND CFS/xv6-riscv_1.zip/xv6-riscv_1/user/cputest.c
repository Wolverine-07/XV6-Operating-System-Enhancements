#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
  int id = 0;
  if(argc > 1) {
    id = atoi(argv[1]);
  }
  
  int pid = getpid();
  printf("CPU test process %d (PID: %d) starting\n", id, pid);
  
  // CPU intensive loop
  for(int i = 0; i < 1000000; i++) {
    if(i % 100000 == 0) {
      printf("Process %d: iteration %d\n", id, i);
    }
    // Simulate some work
    for(int j = 0; j < 100; j++) {
      int dummy = j * j;
      (void)dummy; // Prevent optimization
    }
  }
  
  printf("CPU test process %d (PID: %d) finished\n", id, pid);
  exit(0);
}
