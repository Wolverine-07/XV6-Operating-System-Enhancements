#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Test Multi-Level Feedback Queue Scheduler
int
main(int argc, char *argv[])
{
  printf("MLFQ Test: Creating multiple processes with different behaviors\n\n");
  
  int pid1, pid2, pid3;
  
  // CPU-intensive process (should be demoted quickly)
  if((pid1 = fork()) == 0) {
    printf("Process 1 (PID %d): CPU-intensive task starting\n", getpid());
    for(int i = 0; i < 100000; i++) {
      // CPU-bound work
      for(int j = 0; j < 1000; j++) {
        // Busy loop
      }
      if(i % 10000 == 0) {
        printf("Process 1: iteration %d\n", i);
      }
    }
    printf("Process 1: CPU-intensive task completed\n");
    exit(0);
  }
  
  // I/O bound process (should stay in higher queues)
  if((pid2 = fork()) == 0) {
    printf("Process 2 (PID %d): I/O-bound task starting\n", getpid());
    for(int i = 0; i < 20; i++) {
      printf("Process 2: I/O operation %d\n", i);
      // Simulate I/O wait with pause
      pause(1);
    }
    printf("Process 2: I/O-bound task completed\n");
    exit(0);
  }
  
  // Mixed workload process
  if((pid3 = fork()) == 0) {
    printf("Process 3 (PID %d): Mixed workload starting\n", getpid());
    for(int i = 0; i < 10; i++) {
      // Some CPU work
      for(int j = 0; j < 5000; j++) {
        // Busy loop
      }
      printf("Process 3: mixed iteration %d\n", i);
      if(i % 3 == 0) {
        // Simulate occasional I/O wait with pause
        pause(1);
      }
    }
    printf("Process 3: Mixed workload completed\n");
    exit(0);
  }
  
  // Parent process waits and monitors
  printf("Parent: All processes started\n");
  printf("Parent: Use Ctrl+Y to see process queue information\n");
  
  // Wait for children
  wait(0);
  wait(0);
  wait(0);
  
  printf("MLFQ Test completed\n");
  exit(0);
}
