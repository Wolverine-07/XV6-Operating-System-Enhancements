#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Test B.2: Virtual Runtime Tracking
int
main(int argc, char *argv[])
{
  printf("=== Testing B.2: Virtual Runtime Tracking ===\n");
  printf("This test verifies vruntime updates during execution\n");
  printf("Expected: vruntime should increase monotonically\n\n");
  
  printf("Press Ctrl+Y repeatedly to see vruntime changes\n");
  printf("Look for VRUNTIME column in process dump\n\n");
  
  int pid = getpid();
  printf("Process PID %d starting vruntime tracking test\n", pid);
  
  // Perform CPU-intensive work in phases
  for(int phase = 1; phase <= 5; phase++) {
    printf("B.2 Test Phase %d: Starting CPU burst\n", phase);
    
    // CPU intensive work
    for(int i = 0; i < 50000; i++) {
      int dummy = i * i * i % 1000;
      (void)dummy;
    }
    
    printf("B.2 Test Phase %d: Completed - check vruntime increase\n", phase);
    pause(10); // Give time to observe vruntime
  }
  
  printf("B.2 Test completed. Vruntime should have increased significantly\n");
  exit(0);
}
