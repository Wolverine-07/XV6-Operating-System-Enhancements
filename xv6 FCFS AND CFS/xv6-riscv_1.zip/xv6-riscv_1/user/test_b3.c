#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Test B.3: CFS Scheduling Algorithm
int
main(int argc, char *argv[])
{
  printf("=== Testing B.3: CFS Scheduling Algorithm ===\n");
  printf("This test verifies fair scheduling based on vruntime\n");
  printf("Expected: Process with lowest vruntime gets scheduled next\n\n");
  
  int child_count = 3;
  
  printf("Creating %d child processes for fair scheduling test\n", child_count);
  
  for(int i = 0; i < child_count; i++) {
    int pid = fork();
    if(pid == 0) {
      // Child process
      int child_id = i + 1;
      printf("Child %d (PID: %d) starting execution\n", child_id, getpid());
      
      // Each child does different amounts of work to create vruntime differences
      int work_amount = (i + 1) * 30000;
      
      for(int j = 0; j < work_amount; j++) {
        if(j % 10000 == 0) {
          printf("Child %d: Work iteration %d, vruntime should be tracked\n", child_id, j);
        }
        int dummy = j * j % 1000;
        (void)dummy;
      }
      
      printf("Child %d completed work\n", child_id);
      exit(0);
    } else if(pid > 0) {
      printf("Created child %d with PID: %d\n", i + 1, pid);
    } else {
      printf("Fork failed for child %d\n", i + 1);
      exit(1);
    }
  }
  
  printf("\nB.3 Test: All children created. Observe scheduling fairness:\n");
  printf("- Press Ctrl+Y to see process states and vruntimes\n");
  printf("- Processes with lower vruntime should get more CPU time\n");
  
  // Wait for all children
  for(int i = 0; i < child_count; i++) {
    wait(0);
    printf("Child %d completed\n", i + 1);
  }
  
  printf("B.3 Test completed. Fair scheduling should have been observed\n");
  exit(0);
}
