#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Test program to display process information
int
main(int argc, char *argv[])
{
  printf("=== Process Dump Test ===\n");
  printf("This program demonstrates process information display\n");
  printf("Press Ctrl+Y in xv6 to see live process dump\n");
  printf("If Ctrl+Y doesn't work, this shows the expected format:\n\n");
  
  printf("Expected CFS Process Dump Format:\n");
  printf("PID\tSTATE\tNAME\tVRUNTIME\tNICE\tWEIGHT\tTSLICE\n");
  printf("1\tsleep\tinit\t0\t0\t1024\t20\n");
  printf("2\trun\tsh\t150\t0\t1024\t20\n");
  printf("3\trun\tprocdump_test\t75\t0\t1024\t20\n");
  
  printf("\nNote: Press Ctrl+Y in the xv6 terminal (not VS Code) to see real data\n");
  
  // Do some CPU work to show up in scheduler
  for(int i = 0; i < 50000; i++) {
    if(i % 10000 == 0) {
      printf("Working... iteration %d (try Ctrl+Y now)\n", i);
      pause(5); // Give time to press Ctrl+Y
    }
    int dummy = i * i % 1000;
    (void)dummy;
  }
  
  printf("Test completed. Remember: Ctrl+Y works in xv6 terminal, not VS Code!\n");
  exit(0);
}
