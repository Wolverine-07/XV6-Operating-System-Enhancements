#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Test nice system call and weight-based vruntime progression
int
main(int argc, char *argv[])
{
  printf("=== Testing Nice System Call and CFS Weight Influence ===\n");
  
  // Test different nice values
  int pids[3];
  
  printf("=== Starting process creation ===\n");
  
  // Create high priority process (nice = -10)
  if((pids[0] = fork()) == 0) {
    printf("[Starting] High Priority Process - PID %d\n", getpid());
    nice(-10);  // High priority, should get more CPU time
    printf("[High Priority] PID %d: Set nice to -10 (weight should be ~9548)\n", getpid());
    
    // Do some CPU work and track progress
    int count = 0;
    for(int i = 0; i < 30000; i++) {
      if(i % 6000 == 0) {
        count++;
        printf("[High Priority] PID %d: Work iteration %d\n", getpid(), count);
      }
      // Some computation
      volatile int dummy = i * i % 1000;
      (void)dummy; // Suppress unused variable warning
    }
    printf("[High Priority] PID %d: Completed all work\n", getpid());
    exit(0);
  }
  
  // Create normal priority process (nice = 0)
  if((pids[1] = fork()) == 0) {
    printf("[Starting] Normal Priority Process - PID %d\n", getpid());
    nice(0);  // Normal priority, default weight
    printf("[Normal Priority] PID %d: Set nice to 0 (weight should be 1024)\n", getpid());
    
    // Do some CPU work and track progress
    int count = 0;
    for(int i = 0; i < 30000; i++) {
      if(i % 6000 == 0) {
        count++;
        printf("[Normal Priority] PID %d: Work iteration %d\n", getpid(), count);
      }
      // Some computation
      volatile int dummy = i * i % 1000;
      (void)dummy; // Suppress unused variable warning
    }
    printf("[Normal Priority] PID %d: Completed all work\n", getpid());
    exit(0);
  }
  
  // Create low priority process (nice = 10)
  if((pids[2] = fork()) == 0) {
    printf("[Starting] Low Priority Process - PID %d\n", getpid());
    nice(10);  // Low priority, should get less CPU time
    printf("[Low Priority] PID %d: Set nice to 10 (weight should be ~110)\n", getpid());
    
    // Do some CPU work and track progress
    int count = 0;
    for(int i = 0; i < 30000; i++) {
      if(i % 6000 == 0) {
        count++;
        printf("[Low Priority] PID %d: Work iteration %d\n", getpid(), count);
      }
      // Some computation
      volatile int dummy = i * i % 1000;
      (void)dummy; // Suppress unused variable warning
    }
    printf("[Low Priority] PID %d: Completed all work\n", getpid());
    exit(0);
  }
  
  // Parent process: Monitor the children
  printf("[Parent] PID %d: Created 3 children with different nice values\n", getpid());
  printf("[Parent] High priority child: %d (nice -10)\n", pids[0]);
  printf("[Parent] Normal priority child: %d (nice 0)\n", pids[1]);
  printf("[Parent] Low priority child: %d (nice 10)\n", pids[2]);
  printf("[Parent] Watch the scheduling order and progress rates!\n");
  printf("[Parent] High priority process should finish first.\n");
  printf("[Parent] Press Ctrl+Y to see process weights and vruntime values.\n\n");
  
  // Wait for all children to complete
  for(int i = 0; i < 3; i++) {
    wait(0);
  }
  
  printf("\n=== Nice Test Completed ===\n");
  printf("Expected behavior:\n");
  printf("- High priority process (nice -10) should finish first\n");
  printf("- Low priority process (nice 10) should finish last\n");
  printf("- vruntime should progress slower for high priority processes\n");
  printf("- Weight values should be: nice -10 = 9548, nice 0 = 1024, nice 10 = 110\n");
  printf("- Time slices should be proportional to weights\n");
  printf("- Press Ctrl+Y during execution to see process details\n");
  
  exit(0);
}
